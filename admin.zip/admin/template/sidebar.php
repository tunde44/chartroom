<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
		
		<ul class="nav menu">
			<li class="active"><a href="dashboard.php"><svg class="glyph stroked dashboard-dial"><use xlink:href="#stroked-dashboard-dial"></use></svg> Dashboard</a></li>
			<li><a href="course.php"><svg class="glyph stroked calendar"><use xlink:href="#stroked-calendar"></use></svg> Cources</a></li>
			<li><a href="student.php"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg> Students</a></li>
			
			<li><a href="module.php"><svg class="glyph stroked calendar"><use xlink:href="#stroked-calendar"></use></svg> Module (Subject)</a></li>
			<li><a href="teacher.php"><svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg> Teachers</a></li>
			<li><a href="topic.php"><svg class="glyph stroked calendar"><use xlink:href="#stroked-calendar"></use></svg> Topics</a></li>
			<li><a href="news.php"><svg class="glyph stroked app window with content"><use xlink:href="#stroked-app-window-with-content"/></svg> News</a></li>
			
			
			<!--<li><a href="widgets.html"><svg class="glyph stroked calendar"><use xlink:href="#stroked-calendar"></use></svg> Widgets</a></li>
			<li><a href="tables.html"><svg class="glyph stroked table"><use xlink:href="#stroked-table"></use></svg> Tables</a></li>
			<li><a href="forms.html"><svg class="glyph stroked pencil"><use xlink:href="#stroked-pencil"></use></svg> Forms</a></li>
			<li><a href="panels.html"><svg class="glyph stroked app-window"><use xlink:href="#stroked-app-window"></use></svg> Alerts &amp; Panels</a></li>
			
			<li class="parent ">
				<a href="#">
					<span data-toggle="collapse" href="#sub-item-1"><svg class="glyph stroked chevron-down"><use xlink:href="#stroked-chevron-down"></use></svg></span> Dropdown 
				</a>
				<ul class="children collapse" id="sub-item-1">
					<li>
						<a class="" href="#">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Sub Item 1
						</a>
					</li>
					<li>
						<a class="" href="#">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Sub Item 2
						</a>
					</li>
					<li>
						<a class="" href="#">
							<svg class="glyph stroked chevron-right"><use xlink:href="#stroked-chevron-right"></use></svg> Sub Item 3
						</a>
					</li>
				</ul>
			</li>
			<li role="presentation" class="divider"></li>-->
			
		</ul>

	</div><!--/.sidebar-->